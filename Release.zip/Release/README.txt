Ứng dụng BILY FLOWER SHOP
Đồ án cuối kì - Phương pháp lập trình hướng đối tượng
Nhóm 6 - Lớp 20CTT1TN1
Học kì 1 - Năm học 2021-2022
Trường Đại học Khoa học Tự nhiên - ĐHQG TP.HCM

////////////////////////////////////////////////////////////////////////////////////////

Ứng dụng chạy ổn định nhất trên hệ điều hành Window 10 - 64bit.

File thực thi: BILY.exe

Trong trường hợp khởi động ứng dụng và gặp lỗi như thiếu các file như MSVCP140.dll, VCRUNTIME140.dll,... hãy mở file  vc_redist.x64.exe để cài đặt những file bị thiếu đó trước, sau đó mở lại file BILY.exe để khởi động ứng dụng.